import Content from "../components/common/Content";

export default function Restaurants() {
  return <Content>Restaurants Page</Content>;
}
