import Content from "../components/common/Content";

export default function Orders() {
  return <Content>Orders Page</Content>;
}
