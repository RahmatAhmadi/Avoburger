import Content from "../components/common/Content";

export default function Dashboard() {
  return <Content>Dashboard Page</Content>;
}
