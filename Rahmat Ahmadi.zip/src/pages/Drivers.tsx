import Content from "../components/common/Content";

export default function Drivers() {
  return <Content>Drivers Page</Content>;
}
